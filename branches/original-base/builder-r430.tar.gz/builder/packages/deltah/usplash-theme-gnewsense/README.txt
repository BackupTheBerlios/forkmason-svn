This is the usplash artwork package for the gnewsense distribution.
The original package come from Ubuntu.

The automatic image generation is from Jean Schurger <jean@schurger.org>

